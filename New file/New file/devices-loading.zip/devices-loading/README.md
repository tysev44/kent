# Devices Loading

A Pen created on CodePen.

Original URL: [https://codepen.io/jkantner/pen/mdgejxq](https://codepen.io/jkantner/pen/mdgejxq).

An Apple-themed preloader based on a [Dribbble shot](https://dribbble.com/shots/23202363-Devices-Loading) by Luke.