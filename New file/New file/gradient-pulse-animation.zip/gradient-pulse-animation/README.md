# Gradient Pulse animation

A Pen created on CodePen.

Original URL: [https://codepen.io/simeydotme/pen/QwjEgmq](https://codepen.io/simeydotme/pen/QwjEgmq).

Based on the tweet from Jakob (and Aaron Iker), I really wanted try to recreate the gradient pulse/explosion effect.

https://x.com/Jakubantalik/status/1947960379356897396

I've never seen this exact kind of effect where it pulses and then becomes a psuedo-border before!