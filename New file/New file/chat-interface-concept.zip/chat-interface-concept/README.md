# Chat Interface Concept

A Pen created on CodePen.

Original URL: [https://codepen.io/emilcarlsson/pen/ZOQZaV](https://codepen.io/emilcarlsson/pen/ZOQZaV).

A concept for a chat interface. Try writing a new message! :)