# Smooth Corners

A Pen created on CodePen.

Original URL: [https://codepen.io/aaroniker/pen/pvJZaPJ](https://codepen.io/aaroniker/pen/pvJZaPJ).

