CSS.paintWorklet.addModule('https://unpkg.com/smooth-corners');
