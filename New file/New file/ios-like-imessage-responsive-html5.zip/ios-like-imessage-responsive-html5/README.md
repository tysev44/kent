# iOS Like iMessage Responsive HTML5

A Pen created on CodePen.

Original URL: [https://codepen.io/adobewordpress/pen/wGGMaV](https://codepen.io/adobewordpress/pen/wGGMaV).

I create Apple's iOS9 iMessage front-end development with HTML, CSS and jQuery. It's completely responsive. Enjoy!

http://www.adobewordpress.com/iphone-mesajlar-ekrani