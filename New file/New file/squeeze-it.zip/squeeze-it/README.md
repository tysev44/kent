# Squeeze it

A Pen created on CodePen.

Original URL: [https://codepen.io/bertdida/pen/rqogZM](https://codepen.io/bertdida/pen/rqogZM).

Based on Alvaro Secilla's work on dribbble: https://dribbble.com/shots/4101920-Microinteraction-01