# Daily UI #002 Credit Card Checkout

A Pen created on CodePen.

Original URL: [https://codepen.io/emilcarlsson/pen/pbGxNa](https://codepen.io/emilcarlsson/pen/pbGxNa).

