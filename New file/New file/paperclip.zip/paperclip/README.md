# Paperclip

A Pen created on CodePen.

Original URL: [https://codepen.io/joeyhoer/pen/ALjNGq](https://codepen.io/joeyhoer/pen/ALjNGq).

Single element paperclip and paper, layered appropriately