# Comic book style layout with CSS Grid

A Pen created on CodePen.

Original URL: [https://codepen.io/rrenula/pen/LzLXYJ](https://codepen.io/rrenula/pen/LzLXYJ).

Going crazy again with Grid CSS. This one is done in 30 minutes so the code quality isn't that good. I brute force my way to get the layout right quickly by using the dev tools as well. Anyway, only works well on browsers with Grid AND Clip Path. For Clip Path, it should work with Firefox 54 and above because I don't use SVG to generate it. Older browsers will get a boring layout instead.