# Wave animation

A Pen created on CodePen.

Original URL: [https://codepen.io/ludviglindblom/pen/ZErpPrJ](https://codepen.io/ludviglindblom/pen/ZErpPrJ).

Just trying to simulate a wave animation using only one DOM element and CSS.