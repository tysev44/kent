# JavaScript Web Speech API API - SpeechSynthesisUtterance - You clicked the button

A Pen created on CodePen.

Original URL: [https://codepen.io/ludviglindblom/pen/zYaLeWe](https://codepen.io/ludviglindblom/pen/zYaLeWe).

