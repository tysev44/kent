# [demo] Bento grid using grid areas for responsive postitioning.

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/eYqNpON](https://codepen.io/cbolson/pen/eYqNpON).

