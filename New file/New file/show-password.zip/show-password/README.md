# Show password

A Pen created on CodePen.

Original URL: [https://codepen.io/bertdida/pen/WaKjmd](https://codepen.io/bertdida/pen/WaKjmd).

Unmask and masking input fields.