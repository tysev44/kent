# Complex Bento Layout

A Pen created on CodePen.

Original URL: [https://codepen.io/camilo-micheletto/pen/YzBYPvv](https://codepen.io/camilo-micheletto/pen/YzBYPvv).

