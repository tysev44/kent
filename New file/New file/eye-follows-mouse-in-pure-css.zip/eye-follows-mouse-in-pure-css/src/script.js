// Set $debug to true, and play with the animations.

// I suggest to set equal $eye-lid-height and $pupil-y values for every .eventListener that are on the same rows.
// For example; .eventListener's 1, 2, 3 and 4 should all have same values for these variables. Enjoy... :)