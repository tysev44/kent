# Eye-follows-mouse in pure CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/bertdida/pen/EdLXWg](https://codepen.io/bertdida/pen/EdLXWg).

A pure CSS version of eye-follow-mouse using CSS `grid`,  general sibling combinator (`~`) and `:hover` selectors.

Design idea from  Bertil Boisen's work on dribbble: https://dribbble.com/shots/2245136--Pfffff