# Paperclip CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/strasner/pen/xEwpeJ](https://codepen.io/strasner/pen/xEwpeJ).

