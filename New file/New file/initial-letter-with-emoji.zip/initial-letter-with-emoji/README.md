# Initial Letter with Emoji

A Pen created on CodePen.

Original URL: [https://codepen.io/chriscoyier/pen/jEEaWLE](https://codepen.io/chriscoyier/pen/jEEaWLE).

