# iPhone Widget Scroll Animation

A Pen created on CodePen.

Original URL: [https://codepen.io/gibsonmurray/pen/RwEQKrY](https://codepen.io/gibsonmurray/pen/RwEQKrY).

This scroll animation was seen in [Haptic's site](haptic.app) and is a demonstration of this effect being done with GSAP