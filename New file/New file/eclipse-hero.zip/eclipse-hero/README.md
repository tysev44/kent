# Eclipse Hero

A Pen created on CodePen.

Original URL: [https://codepen.io/RAFA3L/pen/RwOMEEa](https://codepen.io/RAFA3L/pen/RwOMEEa).

