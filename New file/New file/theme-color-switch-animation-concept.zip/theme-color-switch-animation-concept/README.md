# 🎨 Theme color switch animation concept

A Pen created on CodePen.

Original URL: [https://codepen.io/aaroniker/pen/OPPgzKW](https://codepen.io/aaroniker/pen/OPPgzKW).

From https://dribbble.com/shots/3483277-Splash-Loader-Experiment