# Vue Upload Button component

A Pen created on CodePen.

Original URL: [https://codepen.io/BetaHuhn/pen/OJMQZav](https://codepen.io/BetaHuhn/pen/OJMQZav).

Vue Upload/Save button component. Original non-vue version by Aaron Iker (https://codepen.io/aaroniker/pen/ZVOrOZ)