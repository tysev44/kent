# Marvel Character Select

A Pen created on CodePen.

Original URL: [https://codepen.io/RAFA3L/pen/raBJjgO](https://codepen.io/RAFA3L/pen/raBJjgO).

