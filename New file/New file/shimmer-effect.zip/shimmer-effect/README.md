# Shimmer effect

A Pen created on CodePen.

Original URL: [https://codepen.io/ludviglindblom/pen/LEVrdXE](https://codepen.io/ludviglindblom/pen/LEVrdXE).

