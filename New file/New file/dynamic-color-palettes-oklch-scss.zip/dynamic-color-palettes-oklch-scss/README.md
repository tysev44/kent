# Dynamic Color Palettes (oklch, SCSS)

A Pen created on CodePen.

Original URL: [https://codepen.io/konstantindenerz/pen/ogXrgJw](https://codepen.io/konstantindenerz/pen/ogXrgJw).

Dynamic color palettes generated with SCSS using OKLCH and a cosine-based chroma curve. The goal was to dynamically construct the Material 3 reference tokens. You can find the tokens in the dev tools on :root.