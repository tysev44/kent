# Simple registration form

A Pen created on CodePen.

Original URL: [https://codepen.io/bertdida/pen/XxZjNy](https://codepen.io/bertdida/pen/XxZjNy).

This is part 2 of my pure CSS form validation and interactions. On this pen I added more input fields and simple progress tracking animation.

Design inspired from Xavier Coulombe-M's work on dribbble: https://dribbble.com/shots/2510592-Simple-register-form

Part 1: https://codepen.io/bertdida/full/xyPKRX/