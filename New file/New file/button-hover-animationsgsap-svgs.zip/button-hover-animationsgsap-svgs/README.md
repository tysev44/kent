# Button Hover Animations - GSAP & SVGs

A Pen created on CodePen.

Original URL: [https://codepen.io/astuefer-the-sasster/pen/YzdJxyN](https://codepen.io/astuefer-the-sasster/pen/YzdJxyN).

Inspired by a pen from Aaron Iker: https://codepen.io/aaroniker/pen/gOdBBKq?editors=0010