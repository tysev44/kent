# Css/Js/Gsap  Mask Lamp

A Pen created on CodePen.

Original URL: [https://codepen.io/Since1979/pen/podveKZ](https://codepen.io/Since1979/pen/podveKZ).

