# Shadow Spy (light illuminated text)

A Pen created on CodePen.

Original URL: [https://codepen.io/greg-taylor/pen/pvjZxJP](https://codepen.io/greg-taylor/pen/pvjZxJP).

