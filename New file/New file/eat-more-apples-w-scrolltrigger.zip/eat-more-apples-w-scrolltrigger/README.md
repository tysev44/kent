# Eat more apples 🍏 w/ ScrollTrigger

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/KKVMmdz](https://codepen.io/jh3y/pen/KKVMmdz).

