# Emoji (Loudly Crying. Zombie. One-Eyed Monster)

A Pen created on CodePen.

Original URL: [https://codepen.io/bertdida/pen/jpXpOL](https://codepen.io/bertdida/pen/jpXpOL).

Based on Mohammad Amiri's work on Dribbble:  https://dribbble.com/shots/4866955-Emoji-Loudly-Crying-Zombie-One-Eyed-Monster

Not really for zombie :/