# Smooth Corners

A Pen created on CodePen.

Original URL: [https://codepen.io/aaroniker/pen/RNPYXGr](https://codepen.io/aaroniker/pen/RNPYXGr).

