# Notify me

A Pen created on CodePen.

Original URL: [https://codepen.io/bertdida/pen/xyPKRX](https://codepen.io/bertdida/pen/xyPKRX).

Form validation using HTML `required` and `pattern` attributes together with CSS` :required` and `:valid` selectors.

Design inspired by Oleg Frolov's work on dribbble: https://dribbble.com/shots/3072293-Notify-me